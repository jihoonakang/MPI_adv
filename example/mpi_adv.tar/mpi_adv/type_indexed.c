#include <stdio.h>
#include <mpi.h>

#define N 20

int main(int argc, char *argv[])
{
   int i, j, nrank, nprocs;
   MPI_Datatype inewtype;

   MPI_Init(&argc, &argv);
   MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
   MPI_Comm_rank(MPI_COMM_WORLD, &nrank);

   /* Upper triangular matrix */ 
   double a[N][N]; 
   int disp[N], blocklen[N]; 
   MPI_Datatype upper; 

   if (nrank == 0)
   {
      for (i=0; i<N; i++) 
      {
         for (j=0; j<N; j++)
         {
            a[i][j]= (double)(i+j);
         }
      }
   }
   else
   {
      for (i=0; i<N; i++) 
         for (j=0; j<N; j++)
         {
            a[i][j]= 0.0;
         }
   }

   /* compute start and size of rows */ 
   for (i=0;i<N;i++)
   { 
      disp[i]=N*i+i; 
      blocklen[i]=N-i; 
   }

   /* create a datatype for upper triangular matrix */ 
   MPI_Type_indexed(N,blocklen,disp,MPI_DOUBLE,&upper); 
   MPI_Type_commit(&upper); 

   /* ... send it ... */ 
   if (nrank == 0)
       MPI_Send(a,1,upper,1, 99, MPI_COMM_WORLD); 
   else
       MPI_Recv(a,1,upper,0, 99, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 

   MPI_Type_free(&upper);

   if(nrank == 1)
   {

      printf("myrank = %d, buf = ", nrank);

      for (i=0; i<N; i++) printf(" %.2f", a[10][i]);
      printf("\n");
   }

   MPI_Finalize();

   return 0;
}


