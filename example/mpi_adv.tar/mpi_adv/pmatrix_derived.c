/*
 *     Example Name : pmatrix_derived.c
 *         Compile      : $ mpicc -g -o pmatrix_derived -Wall pmatrix_derived.c
 *             Run          : $ mpirun -np 5 -hostfile hosts pmatrix_derived
 *             */

#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <time.h>

#define NP  5   // NP must be same with the number of processor (-np 5)

int main(int argc, char *argv[])
{
    int nRank, nProcs, ROOT = 0, i, j;
    int nMatrixA[NP][NP], nMatrixB[NP][NP], nMatrixC[NP][NP], nMatrixTotal[NP][NP];
    MPI_Datatype row_new_type;

    MPI_Init(&argc, &argv); 
    MPI_Comm_rank(MPI_COMM_WORLD, &nRank);
    MPI_Comm_size(MPI_COMM_WORLD, &nProcs);

    srand(time(NULL));

    if (nRank == ROOT) {
        printf("nMatrixA\n");
        for (i = 0; i < NP; i++) {
            for (j = 0; j < NP; j++) {
                nMatrixA[i][j] = rand() % 2;
                nMatrixB[i][j] = rand() % 2;
                nMatrixC[i][j] = 0;
                printf("%d ", nMatrixA[i][j]);
            }
            printf("\n");
        }
    }

    MPI_Type_contiguous(NP, MPI_INT, &row_new_type);
    MPI_Type_commit(&row_new_type);

        MPI_Bcast(nMatrixA[0], NP, row_new_type, ROOT, MPI_COMM_WORLD);
        MPI_Bcast(nMatrixB[0], NP, row_new_type, ROOT, MPI_COMM_WORLD);
        MPI_Bcast(nMatrixC[0], NP, row_new_type, ROOT, MPI_COMM_WORLD);

    MPI_Type_free(&row_new_type);

    if (nRank == ROOT) {
        printf("-----------\n");
        printf("nMatrixB\n");
        for (i = 0; i < NP; i++) {
            for (j = 0; j < NP; j++) {
                printf("%d ", nMatrixB[i][j]);
            }
            printf("\n");
        }
    }

    for (i = 0; i < NP; i++)
        for (j = 0; j < NP; j++)
            nMatrixC[nRank][i]=nMatrixC[nRank][i] + nMatrixA[nRank][j] * nMatrixB[j][i];

    MPI_Reduce(nMatrixC, nMatrixTotal, NP*NP, MPI_INT, MPI_SUM, ROOT, MPI_COMM_WORLD);

    if (nRank == ROOT) {
        printf("-----------\n");
        printf("nMatrixTotal\n");
        for (i = 0; i < NP; i++) {
            for (j = 0; j < NP; j++)
                printf("%d ", nMatrixTotal[i][j]);
            printf("\n");
        }
    }
    printf("\n");
    MPI_Finalize();
    
    return 0;
}

