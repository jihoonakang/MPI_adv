/*example of parallel UNIX write into separate files */
#include <mpi.h>
#include <stdio.h>
#define BUFSIZE 100
void main (int argc, char *argv[]){
  int i, nprocs, myrank, buf[BUFSIZE] ;
  char filename[128];
  FILE *myfile;
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  for(i=0; i<BUFSIZE; i++)
    buf[i] = myrank * BUFSIZE + i;
  sprintf(filename, "testfile.%d", myrank);
  myfile = fopen(filename, "wb");
  fwrite(buf, sizeof(int), BUFSIZE, myfile);
  fclose(myfile);
  MPI_Finalize();
} 

