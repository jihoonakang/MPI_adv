#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[])
{
   int i, nrank, nprocs, buf[20];
   MPI_Datatype inewtype;
   MPI_Init(&argc, &argv);
   MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
   MPI_Comm_rank(MPI_COMM_WORLD, &nrank);

   if (nrank == 0)
      for (i=0; i<20; i++) buf[i] = i+1;
   else
      for (i=0; i<20; i++) buf[i] = 0;

   MPI_Type_vector(4, 3, 5, MPI_INT, &inewtype);
   MPI_Type_commit(&inewtype);
   MPI_Bcast(buf, 1, inewtype, 0, MPI_COMM_WORLD);

   printf("myrank = %d, buf = ", nrank);

   for (i=0; i<20; i++) printf(" %d", buf[i]);
   printf("\n");

   MPI_Finalize();
   return 0;
}

