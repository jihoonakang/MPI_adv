from mpi4py import MPI
import numpy as np

comm = MPI.COMM_WORLD

size = comm.Get_size()
rank = comm.Get_rank()

if rank == 0 :
    ibuf = np.arange(1, 21, dtype = np.int32)
else :
    ibuf = np.zeros(20, dtype = np.int32)

inewtype = MPI.Datatype.Create_vector(MPI.INTEGER4, 4, 3, 5)
MPI.Datatype.Commit(inewtype)
comm.Bcast((ibuf, 1, inewtype), 0)

#inewtype = MPI.Datatype.Create_vector(MPI.INTEGER4, 1, 3, 5)
#inewtype2 = MPI.Datatype.Create_resized(inewtype, 0, 5*4*4)
#MPI.Datatype.Commit(inewtype2)
#comm.Bcast((ibuf, 4, inewtype2), 0)

print(rank, ibuf)


