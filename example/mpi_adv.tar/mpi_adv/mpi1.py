from mpi4py import MPI
print("Hello World!")

