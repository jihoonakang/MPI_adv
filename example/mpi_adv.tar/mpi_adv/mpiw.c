/*example of parallel MPI write into single files */
#include <mpi.h>
#include <stdio.h>
#define BUFSIZE 100

void main (int argc, char *argv[]){
  int i, nprocs, myrank, buf[BUFSIZE] ;
  MPI_File thefile;
  MPI_Offset disp;
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
 for(i=0; i<BUFSIZE; i++)
    buf[i] = myrank * BUFSIZE + i;
  MPI_File_open(MPI_COMM_WORLD, "testfile", 
          MPI_MODE_WRONLY | MPI_MODE_CREATE, MPI_INFO_NULL, &thefile);
  disp = myrank*BUFSIZE*sizeof(int);
  MPI_File_set_view(thefile, disp, MPI_INT, MPI_INT,"native",MPI_INFO_NULL);
  MPI_File_write(thefile, buf, BUFSIZE, MPI_INT, MPI_STATUS_IGNORE);
  MPI_File_close(&thefile);
  MPI_Finalize();
}

